import React from 'react';     
import './App.css';    
import Fileupload from './fileupload'    

function App() {    

  return (    
    <div className="App">    
      <Fileupload></Fileupload>    
    </div>    
  );    
}   
export default App;
