import React from 'react';    
import { post } from 'axios';   
import fs from 'fs';     

class Fileupload extends React.Component {    

        constructor(props) {    
                super(props);   
                this.state = {   
                file: '',  
                type: '',
                returnFile: '',
                response: ''
            };    
        }    

        async submit(e) {    

                e.preventDefault();   
                const url = `http://localhost:5000/api/image/convert`;    
                const formData = new FormData();    
                formData.append('File', this.state.file);
                formData.append('FileType', this.state.type);
                const config = {    
                        headers: {    
                                'content-type': 'multipart/form-data',
                                'Access-Control-Allow-Origin':'*',
                        },
                };    
                
                return post(url, formData, config)
                .then(response => {
                    const outputFilename = '/file.png';
                    fs.writeFileSync(outputFilename, response.data);
                    return outputFilename;
                })
        }

        typeChangeHandler(e) {
            this.setState({ type: e.target.value});
        }

        setFile(e) {   
            this.setState({ file: e.target.files[0] });    
        }    

        render() {    
                return (  
                        <div>    
                                <form onSubmit={e => this.submit(e)}>    
                                <div>    
                                                File Upload    
                                </div>    
                                        <h1>File Upload</h1>   
                                        <input type="file" onChange={e => this.setFile(e)} />  
                                        <h5>Destination File Type:</h5> 
                                        <select value={this.state.type} onChange={e => this.typeChangeHandler(e)}>
                                            <option value="GIF">GIF</option>
                                            <option value="BMP">BMP</option>
                                            <option selected value="PNG">PNG</option>
                                            <option value="JPG">JPG</option>
                                        </select>  
                                        <button className="btn btn-primary" type="submit">Upload</button> 
                                </form>
                                <h1 value={this.state.response}>wow</h1>
                        </div> 
                )    
        }    
}    

export default Fileupload    